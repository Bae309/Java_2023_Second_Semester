package DefaultPackage;

import java.awt.Container;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.DataOutputStream;
import java.io.FileOutputStream;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

// 1. 처리할 이벤트 결정. - 버튼
// 2. 이벤트에 적합한 리스너 인터페이스를 사용하여 클래스 작성
class GUI1 extends JFrame implements ActionListener {
	// 속성으로 텍스트에어리어와 텍스트 필드를 선언 - 예외처리를 하기 위해서 속성으로 일부러 지정
	private JTextArea jta; 
	private JTextField jtf;
	
	public GUI1() { // 생성자
		// 버튼 객체 생성
		JButton jb = new JButton("파일로 저장");
		
		// 한 줄 텍스트 객체 생성 - 파일 저장명 입력
		// JTextField jtf = new JTextField("파일 이름을 입력하시오", 20);
		jtf = new JTextField("파일 이름을 입력하시오", 20);
		
		// 여러줄 텍스트 객체 생성 - 파일 내용 입력
		// JTextArea jta = new JTextArea("파일 내용을 입력하시오", 10,20);
		jta = new JTextArea("파일 내용을 입력하시오", 10,20);
		Container ct = getContentPane(); // 컨테이너 생성
		ct.setLayout(new FlowLayout()); // FlowLayout 배치 관리자 설정
		JPanel pl = new JPanel(); // 판넬 생성
		pl.add(jtf);
		
		pl.add(jb);
		
		ct.add(jta);
		
		ct.add(pl);
		
		//3. 이벤트 받아들일 버튼에 리스너 등록
		jb.addActionListener(this);
		setTitle("GUI Test1");
		setSize(500,300);
		setVisible(true);
		
	}
	
	// 4. 리스너 인터페이스에 선언된 메소드를 오버라이딩하여 이벤트 처리 루틴 작성
	@Override
	public void actionPerformed(ActionEvent ae) {
		try {
			// 입출력을 위한 예외처리
			// 파일 이름으로 출력 객체 생성
			String s = jtf.getText();
			FileOutputStream fos = new FileOutputStream(s);
			DataOutputStream dos = new DataOutputStream(fos);
			
			dos.writeUTF(jta.getText());
			
			fos.close();
			System.out.println(s + "파일이 생성되었습니다.");
		}
		catch (Exception e) {
			
		}
	}
	
}
public class GUITest1 {
	public static void main(String[] args) {
		new GUI1();
	}
}
